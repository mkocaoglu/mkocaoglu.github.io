from scipy.stats import bernoulli as bernoulli
import numpy as np
import time
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import sys
import random

from lemonade_functions import *

if __name__ == "__main__":
    main2()